# Attribution / Notice

Binary Waterfall Android is an unofficial native Android derivative/reimplementation of Binary Waterfall.

Original author: Ella Jameson
Original project: https://github.com/nimaid/binary-waterfall
Original project version used as behavior reference: 3.7.0
Original license: GPL-3.0

Required attribution from the upstream project's README:

Made with the help of Binary Waterfall:
https://github.com/nimaid/binary-waterfall

This Android project is distributed under GPL-3.0; see `LICENSE`.
