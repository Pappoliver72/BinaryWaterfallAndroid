# Binary Waterfall Android

A native Android reimplementation/port of **Binary Waterfall**, the raw-data media player by Ella Jameson.

Original project: https://github.com/nimaid/binary-waterfall

> Made with the help of Binary Waterfall:
> https://github.com/nimaid/binary-waterfall

This derivative project is GPL-3.0 licensed. See `LICENSE`.

## What works

- Open arbitrary files through Android's Storage Access Framework (`*/*`)
- Seekable local files are streamed directly; non-seekable document providers fall back to an app-cache copy
- Raw-byte visualization synchronized to audio position
- Original-style defaults:
  - 48 × 48 visualization
  - `bgrx` color layout
  - mono
  - 1-byte / 8-bit samples
  - 32,000 Hz
  - vertical flip on
  - centered alignment
  - visible playhead
  - viewer up to 120 FPS
- Color format codes: `r/R`, `g/G`, `b/B`, `w/W`, `x`
  - uppercase color codes invert that byte/channel
- Mono/stereo
- 1-, 2-, 3-, and 4-byte raw PCM interpretation
  - 24-bit and 32-bit direct `AudioTrack` playback on Android 12+
  - PCM16 compatibility conversion on older Android versions
- Play/pause
- Restart
- ±5 second seek
- ±1 frame seek
- Seek bar
- Mute/unmute
- Volume
- Start / center / end audio-video alignment
- Horizontal/vertical flip
- Playhead toggle
- PNG current-frame export
- WAV raw-audio export (honors the volume setting)
- MP4 export using Android's native H.264 + AAC encoders and `MediaMuxer`
- No storage permission required; file access is handled through Android document URIs
- No internet permission
- No analytics or tracking code

## Build

Recommended toolchain:

- Android Studio compatible with Android Gradle Plugin 8.13.x
- JDK 17
- Android SDK 36
- Gradle 8.13

Open this folder as an Android Studio project, let Gradle sync, then build/install the `app` module.

Command line, with Gradle 8.13 installed:

```bash
gradle assembleDebug
```

The debug APK will be written to:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions APK build

The included workflow `.github/workflows/android.yml` builds a debug APK on every manual run or push. It uses Gradle 8.13 directly, so a binary Gradle wrapper JAR is not required in this source archive.

## Notes

MP4 export uses a standard AAC input sample rate. The default 32,000 Hz setting works. If you choose a non-standard sample rate for live raw playback, change it to a standard AAC rate before MP4 export.

Classic RIFF/WAV has a roughly 4 GiB size limit, so the WAV exporter rejects files that cannot be represented safely in a normal WAV container.

This is an unofficial Android derivative, not an official release from the original Binary Waterfall author.
