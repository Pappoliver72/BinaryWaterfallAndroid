# Source references

This is an unofficial GPL-3.0 derivative/reimplementation based on the behavior and public source of Binary Waterfall by Ella Jameson.

- Upstream: https://github.com/nimaid/binary-waterfall
- Android AudioTrack / AudioFormat documentation: https://developer.android.com/reference/android/media/AudioTrack and https://developer.android.com/reference/android/media/AudioFormat
- Android MediaCodec / MediaMuxer documentation: https://developer.android.com/reference/android/media/MediaCodec and https://developer.android.com/reference/android/media/MediaMuxer

The About screen and README retain the upstream attribution requested by the original project README.
