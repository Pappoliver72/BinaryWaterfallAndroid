package org.unofficial.binarywaterfall

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.ceil
import kotlin.math.roundToLong

enum class Alignment { START, END, MIDDLE }

data class WaterfallSettings(
    var width: Int = 48,
    var height: Int = 48,
    var colorFormat: String = "bgrx",
    var channels: Int = 1,
    var sampleBytes: Int = 1,
    var sampleRate: Int = 32_000,
    var volume: Int = 100,
    var flipV: Boolean = true,
    var flipH: Boolean = false,
    var alignment: Alignment = Alignment.MIDDLE,
    var playheadVisible: Boolean = true,
    var playerFps: Int = 120,
)

class BinaryWaterfallEngine(private val context: Context) : Closeable {
    private val lock = Any()
    private var pfd: android.os.ParcelFileDescriptor? = null
    private var input: FileInputStream? = null
    private var channel: FileChannel? = null
    private var tempCopy: File? = null

    var settings = WaterfallSettings()
        private set

    var displayName: String = ""
        private set

    var sizeBytes: Long = 0L
        private set

    val isOpen: Boolean get() = channel != null

    val colorBytes: Int get() = settings.colorFormat.length
    val sourceFrameBytes: Int get() = settings.channels * settings.sampleBytes
    val bytesPerSecond: Long get() = settings.sampleRate.toLong() * sourceFrameBytes

    val durationMs: Long
        get() {
            if (!isOpen || sizeBytes <= 0L || bytesPerSecond <= 0L) return 0L
            return ceil((sizeBytes.toDouble() * 1000.0) / bytesPerSecond.toDouble()).toLong()
        }

    fun open(uri: Uri) {
        closeSource()
        val resolver = context.contentResolver
        displayName = queryDisplayName(resolver, uri) ?: uri.lastPathSegment ?: "binary"
        val opened = resolver.openFileDescriptor(uri, "r")
            ?: error("Could not open selected file")
        val stream = FileInputStream(opened.fileDescriptor)
        val ch = stream.channel

        // Most Storage Access Framework providers expose seekable descriptors. Cloud/virtual
        // providers sometimes expose a pipe instead. In that case, copy to cache as a fallback
        // so arbitrary document providers still work.
        var seekable = true
        try {
            ch.position(0L)
        } catch (_: Throwable) {
            seekable = false
        }

        if (seekable) {
            pfd = opened
            input = stream
            channel = ch
            sizeBytes = try { ch.size() } catch (_: Throwable) { querySize(resolver, uri) ?: 0L }
            if (sizeBytes <= 0L) sizeBytes = querySize(resolver, uri) ?: 0L
        } else {
            try { stream.close() } catch (_: Throwable) {}
            try { opened.close() } catch (_: Throwable) {}
            val tmp = File.createTempFile("binary-waterfall-", ".bin", context.cacheDir)
            resolver.openInputStream(uri)?.use { src ->
                tmp.outputStream().buffered(256 * 1024).use { dst -> src.copyTo(dst, 256 * 1024) }
            } ?: error("Could not stream selected file")
            val local = FileInputStream(tmp)
            tempCopy = tmp
            input = local
            channel = local.channel
            sizeBytes = tmp.length()
        }
    }

    fun updateSettings(newSettings: WaterfallSettings) {
        validateSettings(newSettings)
        settings = newSettings.copy()
    }

    fun validateSettings(s: WaterfallSettings) {
        require(s.width >= 4) { "Visualization width must be at least 4" }
        require(s.height >= 4) { "Visualization height must be at least 4" }
        require(s.channels == 1 || s.channels == 2) { "Channels must be 1 or 2" }
        require(s.sampleBytes in 1..4) { "Sample bytes must be 1, 2, 3, or 4" }
        require(s.sampleRate >= 1) { "Sample rate must be at least 1 Hz" }
        require(s.volume in 0..100) { "Volume must be 0..100" }
        require(s.playerFps in 1..120) { "Player FPS must be 1..120" }
        require(s.colorFormat.isNotBlank()) { "Color format cannot be empty" }
        require(s.colorFormat.all { it in "rRgGbBwWx" }) {
            "Color format accepts r/R, g/G, b/B, w/W, and x only"
        }
        val lower = s.colorFormat.lowercase()
        require(lower.count { it == 'r' } <= 1) { "Only one red channel is allowed" }
        require(lower.count { it == 'g' } <= 1) { "Only one green channel is allowed" }
        require(lower.count { it == 'b' } <= 1) { "Only one blue channel is allowed" }
        require(lower.count { it == 'w' } <= 1) { "Only one white channel is allowed" }
        require(lower.any { it in "rgbw" }) { "Color format needs at least one visible channel" }
        require(!(lower.contains('w') && lower.any { it in "rgb" })) {
            "White/grayscale cannot be mixed with RGB channels"
        }
    }

    fun readAt(address: Long, count: Int): ByteArray {
        if (count <= 0 || !isOpen || address >= sizeBytes) return ByteArray(0)
        val start = address.coerceAtLeast(0L)
        val wanted = minOf(count.toLong(), sizeBytes - start).toInt()
        if (wanted <= 0) return ByteArray(0)
        val out = ByteArray(wanted)
        synchronized(lock) {
            val ch = channel ?: return ByteArray(0)
            ch.position(start)
            val buffer = ByteBuffer.wrap(out)
            var readTotal = 0
            while (buffer.hasRemaining()) {
                val n = ch.read(buffer)
                if (n <= 0) break
                readTotal += n
            }
            if (readTotal != out.size) return out.copyOf(readTotal)
        }
        return out
    }

    fun byteAddressForMs(ms: Long): Long {
        if (!isOpen || sizeBytes <= 0L || durationMs <= 0L) return 0L
        val rowBytes = settings.width.toLong() * colorBytes.toLong()
        val totalRows = ceil(sizeBytes.toDouble() / rowBytes.toDouble()).toLong()
        var rowIndex = (totalRows.toDouble() * (ms.coerceIn(0L, durationMs).toDouble() / durationMs.toDouble())).roundToLong()
        rowIndex -= when (settings.alignment) {
            Alignment.START -> settings.height.toLong()
            Alignment.MIDDLE -> (settings.height / 2.0).roundToLong()
            Alignment.END -> 0L
        }
        return rowIndex * rowBytes
    }

    fun audioByteForMs(ms: Long): Long {
        if (bytesPerSecond <= 0L) return 0L
        val raw = (ms.coerceAtLeast(0L) * bytesPerSecond) / 1000L
        val aligned = raw - (raw % sourceFrameBytes.coerceAtLeast(1))
        return aligned.coerceIn(0L, sizeBytes)
    }

    fun msForAudioByte(bytePos: Long): Long {
        if (bytesPerSecond <= 0L) return 0L
        return ((bytePos.coerceIn(0L, sizeBytes) * 1000L) / bytesPerSecond).coerceAtMost(durationMs)
    }

    fun renderBitmap(ms: Long): Bitmap {
        val s = settings
        val pixelCount = s.width * s.height
        val rowBytes = s.width * colorBytes
        val baseAddress = byteAddressForMs(ms)
        val frameByteCount = pixelCount * colorBytes
        val readStart = baseAddress.coerceAtLeast(0L)
        val maxNeeded = if (baseAddress < 0L) {
            (frameByteCount.toLong() + baseAddress).coerceAtLeast(0L)
        } else frameByteCount.toLong()
        val bytes = readAt(readStart, maxNeeded.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        val pixels = IntArray(pixelCount)

        for (p in 0 until pixelCount) {
            val global = baseAddress + p.toLong() * colorBytes.toLong()
            if (global < 0L || global >= sizeBytes) {
                pixels[p] = 0xFF000000.toInt()
                continue
            }
            var r = 0
            var g = 0
            var b = 0
            var src = (global - readStart).toInt()
            for (code in s.colorFormat) {
                if (src !in bytes.indices) break
                val raw = bytes[src].toInt() and 0xFF
                val value = if (code.isUpperCase()) 255 - raw else raw
                when (code.lowercaseChar()) {
                    'r' -> r = value
                    'g' -> g = value
                    'b' -> b = value
                    'w' -> { r = value; g = value; b = value }
                    'x' -> Unit
                }
                src++
            }
            pixels[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        if (s.playheadVisible && pixelCount > 0) {
            val playRow = when (s.alignment) {
                Alignment.END -> 0
                Alignment.START -> s.height - 1
                Alignment.MIDDLE -> ((s.height - 1) / 2.0).roundToLong().toInt()
            }.coerceIn(0, s.height - 1)
            val start = playRow * s.width
            val end = (start + s.width).coerceAtMost(pixels.size)
            for (i in start until end) {
                val c = pixels[i]
                val r = 255 - ((c shr 16) and 0xFF)
                val g = 255 - ((c shr 8) and 0xFF)
                val b = 255 - (c and 0xFF)
                val gray = ((r + g + b) / 3)
                val originalLuma = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
                val contrast = if (originalLuma >= 128) 0 else 255
                val out = (gray + contrast) / 2
                pixels[i] = (0xFF shl 24) or (out shl 16) or (out shl 8) or out
            }
        }

        val transformed = if (!s.flipV && !s.flipH) pixels else IntArray(pixelCount)
        if (transformed !== pixels) {
            for (y in 0 until s.height) {
                for (x in 0 until s.width) {
                    val sx = if (s.flipH) s.width - 1 - x else x
                    val sy = if (s.flipV) s.height - 1 - y else y
                    transformed[y * s.width + x] = pixels[sy * s.width + sx]
                }
            }
        }

        return Bitmap.createBitmap(transformed, s.width, s.height, Bitmap.Config.ARGB_8888)
    }

    fun newSequentialReader(startByte: Long = 0L): SequentialReader {
        return SequentialReader(this, startByte)
    }

    override fun close() = closeSource()

    private fun closeSource() {
        synchronized(lock) {
            try { channel?.close() } catch (_: Throwable) {}
            try { input?.close() } catch (_: Throwable) {}
            try { pfd?.close() } catch (_: Throwable) {}
            channel = null
            input = null
            pfd = null
            try { tempCopy?.delete() } catch (_: Throwable) {}
            tempCopy = null
            sizeBytes = 0L
            displayName = ""
        }
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        return resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }

    private fun querySize(resolver: ContentResolver, uri: Uri): Long? {
        return resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }
    }

    class SequentialReader internal constructor(
        private val engine: BinaryWaterfallEngine,
        startByte: Long,
    ) {
        var position: Long = startByte.coerceIn(0L, engine.sizeBytes)
            private set

        fun read(count: Int): ByteArray {
            val bytes = engine.readAt(position, count)
            position += bytes.size
            return bytes
        }
    }
}
