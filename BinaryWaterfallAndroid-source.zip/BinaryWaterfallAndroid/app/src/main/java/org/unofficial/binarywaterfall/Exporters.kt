package org.unofficial.binarywaterfall

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.OutputStream

object Exporters {
    fun exportFramePng(context: Context, engine: BinaryWaterfallEngine, ms: Long, uri: Uri) {
        context.contentResolver.openOutputStream(uri, "w")?.use { out ->
            engine.renderBitmap(ms).useBitmap { bitmap ->
                check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "PNG export failed" }
            }
        } ?: error("Could not open output file")
    }

    fun exportWav(context: Context, engine: BinaryWaterfallEngine, uri: Uri) {
        require(engine.isOpen) { "No file is open" }
        require(engine.sizeBytes <= 0xFFFF_FFFFL - 36L) { "Classic WAV export is limited to about 4 GB" }
        context.contentResolver.openOutputStream(uri, "w")?.use { rawOut ->
            val out = BufferedOutputStream(rawOut, 64 * 1024)
            writeWavHeader(
                out,
                dataSize = engine.sizeBytes,
                channels = engine.settings.channels,
                sampleRate = engine.settings.sampleRate,
                sampleBytes = engine.settings.sampleBytes,
            )
            var pos = 0L
            while (pos < engine.sizeBytes) {
                val count = minOf(256 * 1024L, engine.sizeBytes - pos).toInt()
                val bytes = engine.readAt(pos, count)
                if (bytes.isEmpty()) break
                out.write(applyGain(bytes, engine.settings.sampleBytes, engine.settings.volume))
                pos += bytes.size
            }
            out.flush()
        } ?: error("Could not open output file")
    }


    private fun applyGain(input: ByteArray, sampleBytes: Int, volume: Int): ByteArray {
        if (volume >= 100) return input
        val gain = volume.coerceIn(0, 100) / 100.0
        val out = input.copyOf()
        var i = 0
        while (i + sampleBytes <= out.size) {
            when (sampleBytes) {
                1 -> {
                    val centered = (out[i].toInt() and 0xFF) - 128
                    val scaled = kotlin.math.round(centered * gain).toInt().coerceIn(-128, 127) + 128
                    out[i] = scaled.toByte()
                }
                2 -> {
                    val raw = ((out[i].toInt() and 0xFF) or ((out[i + 1].toInt() and 0xFF) shl 8)).toShort().toInt()
                    val scaled = kotlin.math.round(raw * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                    out[i] = scaled.toByte()
                    out[i + 1] = (scaled shr 8).toByte()
                }
                3 -> {
                    var raw = (out[i].toInt() and 0xFF) or
                        ((out[i + 1].toInt() and 0xFF) shl 8) or
                        ((out[i + 2].toInt() and 0xFF) shl 16)
                    if ((raw and 0x800000) != 0) raw = raw or -0x1000000
                    val scaled = kotlin.math.round(raw * gain).toInt().coerceIn(-8_388_608, 8_388_607)
                    out[i] = scaled.toByte()
                    out[i + 1] = (scaled shr 8).toByte()
                    out[i + 2] = (scaled shr 16).toByte()
                }
                4 -> {
                    val raw = (out[i].toInt() and 0xFF) or
                        ((out[i + 1].toInt() and 0xFF) shl 8) or
                        ((out[i + 2].toInt() and 0xFF) shl 16) or
                        ((out[i + 3].toInt() and 0xFF) shl 24)
                    val scaled = kotlin.math.round(raw.toDouble() * gain).toLong()
                        .coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt()
                    out[i] = scaled.toByte()
                    out[i + 1] = (scaled shr 8).toByte()
                    out[i + 2] = (scaled shr 16).toByte()
                    out[i + 3] = (scaled shr 24).toByte()
                }
            }
            i += sampleBytes
        }
        return out
    }

    private fun writeWavHeader(
        out: OutputStream,
        dataSize: Long,
        channels: Int,
        sampleRate: Int,
        sampleBytes: Int,
    ) {
        val byteRate = sampleRate.toLong() * channels * sampleBytes
        val blockAlign = channels * sampleBytes
        fun ascii(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
        fun le16(v: Int) {
            out.write(v and 0xFF)
            out.write((v ushr 8) and 0xFF)
        }
        fun le32(v: Long) {
            out.write((v and 0xFF).toInt())
            out.write(((v ushr 8) and 0xFF).toInt())
            out.write(((v ushr 16) and 0xFF).toInt())
            out.write(((v ushr 24) and 0xFF).toInt())
        }
        ascii("RIFF")
        le32(36L + dataSize)
        ascii("WAVE")
        ascii("fmt ")
        le32(16)
        le16(1) // PCM
        le16(channels)
        le32(sampleRate.toLong())
        le32(byteRate)
        le16(blockAlign)
        le16(sampleBytes * 8)
        ascii("data")
        le32(dataSize)
    }

    private inline fun <T> Bitmap.useBitmap(block: (Bitmap) -> T): T {
        return try { block(this) } finally { recycle() }
    }
}
