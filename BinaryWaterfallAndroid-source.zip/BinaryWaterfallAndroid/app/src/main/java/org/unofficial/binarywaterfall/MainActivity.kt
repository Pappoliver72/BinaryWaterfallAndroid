package org.unofficial.binarywaterfall

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.roundToLong
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var engine: BinaryWaterfallEngine
    private val player = RawAudioPlayer()
    private lateinit var waterfall: WaterfallView
    private lateinit var seek: SeekBar
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private lateinit var muteButton: Button
    private lateinit var volume: SeekBar
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private var lastKnownPosition = 0L

    private val uiUpdater = object : Runnable {
        override fun run() {
            updateUi()
            handler.postDelayed(this, 50L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = BinaryWaterfallEngine(this)
        player.attach(engine)
        player.onStateChanged = { isPlaying ->
            runOnUiThread { playButton.text = if (isPlaying) "Pause" else "Play" }
        }
        player.onEnded = { runOnUiThread { updateUi() } }
        buildUi()
        handler.post(uiUpdater)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(30, 31, 34))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(button("Open") { openFile() }, weightParams())
        top.addView(button("Settings") { showSettings() }, weightParams())
        top.addView(button("Export") { showExportDialog() }, weightParams())
        top.addView(button("About") { showAbout() }, weightParams())
        root.addView(top, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        waterfall = WaterfallView(this).apply {
            engine = this@MainActivity.engine
            positionProvider = { currentPosition() }
        }
        root.addView(waterfall, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })

        status = TextView(this).apply {
            setTextColor(Color.rgb(220, 220, 220))
            textSize = 13f
            text = "Open any file to begin."
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        root.addView(status)

        seek = SeekBar(this).apply {
            max = 10_000
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && engine.isOpen) {
                        val ms = ((progress / 10_000.0) * engine.durationMs).roundToLong()
                        lastKnownPosition = ms
                        status.text = statusText(ms)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val progressNow = seekBar?.progress ?: this@MainActivity.seek.progress
                    val ms = ((progressNow / 10_000.0) * engine.durationMs).roundToLong()
                    player.seekToMs(ms)
                    lastKnownPosition = ms
                    userSeeking = false
                }
            })
        }
        root.addView(seek)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controls.addView(button("|<") { player.restart() })
        controls.addView(button("-5s") { player.seekByMs(-5000L) })
        controls.addView(button("<1f") { player.seekByMs(-frameMs()) })
        playButton = button("Play") { player.toggle() }
        controls.addView(playButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(button("1f>") { player.seekByMs(frameMs()) })
        controls.addView(button("+5s") { player.seekByMs(5000L) })
        controls.addView(button(">|") { player.seekToMs(engine.durationMs) })
        root.addView(controls)

        val audioRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        muteButton = button("Mute") {
            val muted = player.toggleMute()
            muteButton.text = if (muted) "Unmute" else "Mute"
        }
        audioRow.addView(muteButton)
        audioRow.addView(TextView(this).apply {
            setTextColor(Color.WHITE)
            text = " Volume "
        })
        volume = SeekBar(this).apply {
            max = 100
            progress = engine.settings.volume
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val s = engine.settings.copy(volume = progress)
                        engine.updateSettings(s)
                        player.refreshVolume()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        audioRow.addView(volume, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(audioRow)

        setContentView(root)
    }

    private fun openFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQ_OPEN)
    }

    private fun showExportDialog() {
        if (!engine.isOpen) {
            toast("Open a file first")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Export")
            .setItems(arrayOf("Current frame as PNG", "Raw interpretation as WAV", "Audio + video as MP4")) { _, which ->
                when (which) {
                    0 -> createDocument("image/png", safeBaseName() + "-frame.png", REQ_SAVE_PNG)
                    1 -> createDocument("audio/wav", safeBaseName() + ".wav", REQ_SAVE_WAV)
                    2 -> createDocument("video/mp4", safeBaseName() + ".mp4", REQ_SAVE_MP4)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun createDocument(type: String, title: String, requestCode: Int) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = type
            putExtra(Intent.EXTRA_TITLE, title)
        }
        startActivityForResult(intent, requestCode)
    }

    @Deprecated("Deprecated in Android API; kept intentionally to avoid an AndroidX dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            when (requestCode) {
                REQ_OPEN -> {
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Throwable) {}
                    val wasPlaying = player.isPlaying()
                    player.pause()
                    engine.open(uri)
                    player.attach(engine)
                    lastKnownPosition = 0L
                    seek.progress = 0
                    if (wasPlaying) player.play()
                    toast("Opened ${engine.displayName}")
                }
                REQ_SAVE_PNG -> {
                    Exporters.exportFramePng(this, engine, currentPosition(), uri)
                    toast("PNG exported")
                }
                REQ_SAVE_WAV -> {
                    Exporters.exportWav(this, engine, uri)
                    toast("WAV exported")
                }
                REQ_SAVE_MP4 -> {
                    val resumeAfter = player.isPlaying()
                    player.pause()
                    val exportName = engine.displayName
                    thread(name = "BinaryWaterfallMp4Export") {
                        try {
                            Mp4Exporter.export(this, engine, uri, progress = { percent ->
                                runOnUiThread { status.text = "Rendering $exportName to MP4: $percent%" }
                            })
                            runOnUiThread {
                                toast("MP4 exported")
                                if (resumeAfter) player.play()
                                updateUi()
                            }
                        } catch (t: Throwable) {
                            runOnUiThread {
                                if (resumeAfter) player.play()
                                AlertDialog.Builder(this)
                                    .setTitle("MP4 export error")
                                    .setMessage(t.message ?: t.javaClass.simpleName)
                                    .setPositiveButton("OK", null)
                                    .show()
                                updateUi()
                            }
                        }
                    }
                }
            }
        } catch (t: Throwable) {
            AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(t.message ?: t.javaClass.simpleName)
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun showSettings() {
        val current = engine.settings.copy()
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        scroll.addView(box)

        fun field(label: String, value: String, numeric: Boolean = true): EditText {
            box.addView(TextView(this).apply { text = label })
            return EditText(this).apply {
                setText(value)
                if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
                box.addView(this)
            }
        }

        val widthField = field("Visualization width", current.width.toString())
        val heightField = field("Visualization height", current.height.toString())
        val colorField = field("Color format (r/R g/G b/B w/W x)", current.colorFormat, numeric = false)
        val rateField = field("Sample rate (Hz)", current.sampleRate.toString())
        val fpsField = field("Viewer FPS (1-120)", current.playerFps.toString())

        box.addView(TextView(this).apply { text = "Audio channels" })
        val channels = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("1 - Mono", "2 - Stereo"))
            setSelection(current.channels - 1)
        }
        box.addView(channels)

        box.addView(TextView(this).apply { text = "Sample size" })
        val sampleBytes = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("1 byte (8-bit)", "2 bytes (16-bit)", "3 bytes (24-bit)", "4 bytes (32-bit)"))
            setSelection(current.sampleBytes - 1)
        }
        box.addView(sampleBytes)

        box.addView(TextView(this).apply { text = "Audio/video alignment" })
        val alignment = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Start of frame", "End of frame", "Center of frame"))
            setSelection(when (current.alignment) { Alignment.START -> 0; Alignment.END -> 1; Alignment.MIDDLE -> 2 })
        }
        box.addView(alignment)

        val flipV = CheckBox(this).apply { text = "Flip vertically"; isChecked = current.flipV }
        val flipH = CheckBox(this).apply { text = "Flip horizontally"; isChecked = current.flipH }
        val playhead = CheckBox(this).apply { text = "Show playhead"; isChecked = current.playheadVisible }
        box.addView(flipV)
        box.addView(flipH)
        box.addView(playhead)

        AlertDialog.Builder(this)
            .setTitle("Binary Waterfall settings")
            .setView(scroll)
            .setPositiveButton("Apply") { _, _ ->
                try {
                    val newSettings = current.copy(
                        width = widthField.text.toString().toInt(),
                        height = heightField.text.toString().toInt(),
                        colorFormat = colorField.text.toString().trim(),
                        channels = channels.selectedItemPosition + 1,
                        sampleBytes = sampleBytes.selectedItemPosition + 1,
                        sampleRate = rateField.text.toString().toInt(),
                        alignment = when (alignment.selectedItemPosition) {
                            0 -> Alignment.START
                            1 -> Alignment.END
                            else -> Alignment.MIDDLE
                        },
                        flipV = flipV.isChecked,
                        flipH = flipH.isChecked,
                        playheadVisible = playhead.isChecked,
                        playerFps = fpsField.text.toString().toInt(),
                        volume = volume.progress,
                    )
                    val pos = currentPosition()
                    val wasPlaying = player.isPlaying()
                    player.pause()
                    engine.updateSettings(newSettings)
                    player.attach(engine)
                    player.seekToMs(pos.coerceAtMost(engine.durationMs))
                    if (wasPlaying) player.play()
                    waterfall.invalidate()
                    updateUi()
                } catch (t: Throwable) {
                    toast(t.message ?: "Invalid settings")
                }
            }
            .setNeutralButton("Defaults") { _, _ ->
                val wasPlaying = player.isPlaying()
                player.pause()
                engine.updateSettings(WaterfallSettings())
                player.attach(engine)
                volume.progress = 100
                if (wasPlaying) player.play()
                updateUi()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("Binary Waterfall Android")
            .setMessage(
                "Native Android port/reimplementation of Binary Waterfall, a Raw Data Media Player by Ella Jameson.\n\n" +
                    "Original project: https://github.com/nimaid/binary-waterfall\n\n" +
                    "Made with the help of Binary Waterfall:\nhttps://github.com/nimaid/binary-waterfall\n\n" +
                    "This derivative project is distributed under GPL-3.0."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun currentPosition(): Long {
        val p = if (player.isPlaying()) player.currentPositionMs() else player.currentPositionMs()
        lastKnownPosition = p
        return p
    }

    private fun updateUi() {
        if (!::status.isInitialized) return
        val ms = currentPosition()
        if (!userSeeking && engine.isOpen && engine.durationMs > 0L) {
            seek.progress = ((ms.toDouble() / engine.durationMs.toDouble()) * 10_000.0).toInt().coerceIn(0, 10_000)
        }
        playButton.text = if (player.isPlaying()) "Pause" else "Play"
        status.text = if (engine.isOpen) statusText(ms) else "Open any file to begin."
    }

    private fun statusText(ms: Long): String {
        val s = engine.settings
        return "${engine.displayName}  |  ${formatTime(ms)} / ${formatTime(engine.durationMs)}  |  " +
            "${formatBytes(engine.sizeBytes)}  |  ${s.width}x${s.height} ${s.colorFormat}  |  " +
            "${s.channels}ch ${s.sampleBytes * 8}-bit ${s.sampleRate} Hz"
    }

    private fun frameMs(): Long = (1000.0 / engine.settings.playerFps.coerceAtLeast(1)).roundToLong().coerceAtLeast(1L)

    private fun formatTime(ms: Long): String {
        val totalSec = ms.coerceAtLeast(0L) / 1000L
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val units = arrayOf("KiB", "MiB", "GiB", "TiB")
        var value = bytes.toDouble()
        var i = -1
        do { value /= 1024.0; i++ } while (value >= 1024.0 && i < units.lastIndex)
        return "%.2f %s".format(value, units[i])
    }

    private fun safeBaseName(): String {
        val n = engine.displayName.ifBlank { "binary-waterfall" }
        return n.substringBeforeLast('.', n).replace(Regex("[^A-Za-z0-9._-]+"), "_")
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { action() }
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()


    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_SPACE -> player.toggle()
            KeyEvent.KEYCODE_DPAD_LEFT -> player.seekByMs(-5000L)
            KeyEvent.KEYCODE_DPAD_RIGHT -> player.seekByMs(5000L)
            KeyEvent.KEYCODE_COMMA -> player.seekByMs(-frameMs())
            KeyEvent.KEYCODE_PERIOD -> player.seekByMs(frameMs())
            KeyEvent.KEYCODE_R -> player.restart()
            KeyEvent.KEYCODE_M -> {
                val muted = player.toggleMute()
                muteButton.text = if (muted) "Unmute" else "Mute"
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                volume.progress = (volume.progress + 5).coerceAtMost(100)
                engine.updateSettings(engine.settings.copy(volume = volume.progress))
                player.refreshVolume()
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                volume.progress = (volume.progress - 5).coerceAtLeast(0)
                engine.updateSettings(engine.settings.copy(volume = volume.progress))
                player.refreshVolume()
            }
            else -> return super.onKeyDown(keyCode, event)
        }
        return true
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player.release()
        engine.close()
        super.onDestroy()
    }

    companion object {
        private const val REQ_OPEN = 1001
        private const val REQ_SAVE_PNG = 1002
        private const val REQ_SAVE_WAV = 1003
        private const val REQ_SAVE_MP4 = 1004
    }
}
