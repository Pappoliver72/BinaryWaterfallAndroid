package org.unofficial.binarywaterfall

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.GLES20
import android.opengl.GLUtils
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

object Mp4Exporter {
    data class Options(
        val fps: Int = 30,
        val maxDimension: Int = 512,
        val videoBitrate: Int = 2_500_000,
        val audioBitrate: Int = 160_000,
    )

    fun export(
        context: Context,
        engine: BinaryWaterfallEngine,
        uri: Uri,
        options: Options = Options(),
        progress: (Int) -> Unit = {},
    ) {
        require(engine.isOpen && engine.sizeBytes > 0L) { "Open a non-empty file first" }
        require(options.fps in 1..120) { "FPS must be 1..120" }
        require(engine.settings.sampleRate in AAC_SAMPLE_RATES) {
            "MP4/AAC export needs a standard AAC sample rate. Try 8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000, 64000, 88200, or 96000 Hz."
        }

        val srcW = engine.settings.width
        val srcH = engine.settings.height
        val scale = options.maxDimension.toDouble() / max(srcW, srcH).toDouble()
        val outW = evenAtLeast2((srcW * scale).roundToInt())
        val outH = evenAtLeast2((srcH * scale).roundToInt())
        val durationUs = engine.durationMs * 1000L
        val videoFrames = max(1L, ceil(durationUs / 1_000_000.0 * options.fps).toLong())

        val pfd = context.contentResolver.openFileDescriptor(uri, "rw")
            ?: error("Could not open MP4 output")
        var muxer: MediaMuxer? = null
        var vCodec: MediaCodec? = null
        var aCodec: MediaCodec? = null
        var inputSurface: Surface? = null
        var egl: CodecInputSurface? = null
        try {
            muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, options.videoBitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, options.fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            vCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            vCodec.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = vCodec.createInputSurface()
            vCodec.start()
            egl = CodecInputSurface(inputSurface, outW, outH)

            val af = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC,
                engine.settings.sampleRate,
                engine.settings.channels,
            ).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, options.audioBitrate)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            }
            aCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            aCodec.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aCodec.start()

            val state = MuxState(muxer)
            val totalAudioFrames = engine.sizeBytes / engine.sourceFrameBytes.coerceAtLeast(1)
            var audioFramesSubmitted = 0L
            var sourceBytePos = 0L

            for (frame in 0 until videoFrames) {
                val ptsUs = frame * 1_000_000L / options.fps
                val ms = ptsUs / 1000L
                val bitmap = engine.renderBitmap(ms)
                try {
                    egl.draw(bitmap, ptsUs)
                } finally {
                    bitmap.recycle()
                }
                drain(vCodec, TrackType.VIDEO, state, endOfStream = false)

                val targetAudioFrames = minOf(
                    totalAudioFrames,
                    ((frame + 1L) * engine.settings.sampleRate.toLong() / options.fps.toLong())
                )
                while (audioFramesSubmitted < targetAudioFrames) {
                    val submitted = feedAudio(
                        codec = aCodec,
                        engine = engine,
                        sourceBytePos = sourceBytePos,
                        sourceFramesSubmitted = audioFramesSubmitted,
                        maxTargetFrames = targetAudioFrames,
                    )
                    if (submitted.frames <= 0) break
                    audioFramesSubmitted += submitted.frames
                    sourceBytePos += submitted.sourceBytes
                    drain(aCodec, TrackType.AUDIO, state, endOfStream = false)
                }
                progress(((frame + 1L) * 95L / videoFrames).toInt().coerceIn(0, 95))
            }

            // Feed any final audio not covered by the frame loop.
            while (audioFramesSubmitted < totalAudioFrames) {
                val submitted = feedAudio(
                    codec = aCodec,
                    engine = engine,
                    sourceBytePos = sourceBytePos,
                    sourceFramesSubmitted = audioFramesSubmitted,
                    maxTargetFrames = totalAudioFrames,
                )
                if (submitted.frames <= 0) break
                audioFramesSubmitted += submitted.frames
                sourceBytePos += submitted.sourceBytes
                drain(aCodec, TrackType.AUDIO, state, endOfStream = false)
            }

            queueAudioEos(aCodec, audioFramesSubmitted, engine.settings.sampleRate)
            vCodec.signalEndOfInputStream()

            var videoDone = false
            var audioDone = false
            while (!videoDone || !audioDone) {
                if (!videoDone) videoDone = drain(vCodec, TrackType.VIDEO, state, endOfStream = true)
                if (!audioDone) audioDone = drain(aCodec, TrackType.AUDIO, state, endOfStream = true)
            }
            state.finish()
            progress(100)
        } finally {
            try { egl?.release() } catch (_: Throwable) {}
            try { inputSurface?.release() } catch (_: Throwable) {}
            try { vCodec?.stop() } catch (_: Throwable) {}
            try { vCodec?.release() } catch (_: Throwable) {}
            try { aCodec?.stop() } catch (_: Throwable) {}
            try { aCodec?.release() } catch (_: Throwable) {}
            try { muxer?.release() } catch (_: Throwable) {}
            try { pfd.close() } catch (_: Throwable) {}
        }
    }

    private data class AudioSubmit(val frames: Long, val sourceBytes: Long)

    private fun feedAudio(
        codec: MediaCodec,
        engine: BinaryWaterfallEngine,
        sourceBytePos: Long,
        sourceFramesSubmitted: Long,
        maxTargetFrames: Long,
    ): AudioSubmit {
        val index = codec.dequeueInputBuffer(10_000)
        if (index < 0) return AudioSubmit(0, 0)
        val buffer = codec.getInputBuffer(index) ?: return AudioSubmit(0, 0)
        buffer.clear()
        val sourceFrameBytes = engine.sourceFrameBytes
        val maxFramesByBuffer = buffer.remaining() / (engine.settings.channels * 2)
        val wantedFrames = minOf(
            maxFramesByBuffer.toLong(),
            maxTargetFrames - sourceFramesSubmitted,
            (engine.sizeBytes - sourceBytePos) / sourceFrameBytes,
        ).coerceAtLeast(0L)
        if (wantedFrames <= 0L) {
            codec.queueInputBuffer(index, 0, 0, sourceFramesSubmitted * 1_000_000L / engine.settings.sampleRate, 0)
            return AudioSubmit(0, 0)
        }
        val sourceBytesCount = (wantedFrames * sourceFrameBytes).toInt()
        val raw = engine.readAt(sourceBytePos, sourceBytesCount)
        val usable = raw.size - raw.size % sourceFrameBytes
        if (usable <= 0) {
            codec.queueInputBuffer(index, 0, 0, sourceFramesSubmitted * 1_000_000L / engine.settings.sampleRate, 0)
            return AudioSubmit(0, 0)
        }
        val rawAligned = if (usable == raw.size) raw else raw.copyOf(usable)
        val pcm16 = toPcm16(rawAligned, engine.settings.sampleBytes, engine.settings.volume)
        buffer.put(pcm16)
        val frames = usable.toLong() / sourceFrameBytes
        val ptsUs = sourceFramesSubmitted * 1_000_000L / engine.settings.sampleRate.toLong()
        codec.queueInputBuffer(index, 0, pcm16.size, ptsUs, 0)
        return AudioSubmit(frames, usable.toLong())
    }

    private fun queueAudioEos(codec: MediaCodec, frames: Long, sampleRate: Int) {
        while (true) {
            val index = codec.dequeueInputBuffer(10_000)
            if (index >= 0) {
                codec.queueInputBuffer(
                    index,
                    0,
                    0,
                    frames * 1_000_000L / sampleRate.toLong(),
                    MediaCodec.BUFFER_FLAG_END_OF_STREAM,
                )
                return
            }
        }
    }

    private enum class TrackType { VIDEO, AUDIO }

    private data class PendingPacket(
        val type: TrackType,
        val bytes: ByteArray,
        val ptsUs: Long,
        val flags: Int,
    )

    private class MuxState(private val muxer: MediaMuxer) {
        var videoTrack = -1
        var audioTrack = -1
        var started = false
        private val pending = ArrayList<PendingPacket>()

        fun onFormat(type: TrackType, format: MediaFormat) {
            when (type) {
                TrackType.VIDEO -> if (videoTrack < 0) videoTrack = muxer.addTrack(format)
                TrackType.AUDIO -> if (audioTrack < 0) audioTrack = muxer.addTrack(format)
            }
            if (!started && videoTrack >= 0 && audioTrack >= 0) {
                muxer.start()
                started = true
                flushPending()
            }
        }

        fun write(type: TrackType, buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
            if (info.size <= 0 || (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) return
            if (started) {
                val track = if (type == TrackType.VIDEO) videoTrack else audioTrack
                buffer.position(info.offset)
                buffer.limit(info.offset + info.size)
                muxer.writeSampleData(track, buffer, info)
            } else {
                val bytes = ByteArray(info.size)
                val oldPos = buffer.position()
                val oldLimit = buffer.limit()
                buffer.position(info.offset)
                buffer.limit(info.offset + info.size)
                buffer.get(bytes)
                buffer.position(oldPos.coerceAtMost(buffer.capacity()))
                buffer.limit(oldLimit.coerceAtMost(buffer.capacity()))
                pending += PendingPacket(type, bytes, info.presentationTimeUs, info.flags)
            }
        }

        private fun flushPending() {
            pending.sortBy { it.ptsUs }
            for (p in pending) {
                val info = MediaCodec.BufferInfo().apply {
                    set(0, p.bytes.size, p.ptsUs, p.flags)
                }
                val track = if (p.type == TrackType.VIDEO) videoTrack else audioTrack
                muxer.writeSampleData(track, ByteBuffer.wrap(p.bytes), info)
            }
            pending.clear()
        }

        fun finish() {
            check(started) { "Encoder produced no muxable tracks" }
            muxer.stop()
            started = false
        }
    }

    private fun drain(
        codec: MediaCodec,
        type: TrackType,
        state: MuxState,
        endOfStream: Boolean,
    ): Boolean {
        val info = MediaCodec.BufferInfo()
        var eos = false
        var idle = 0
        while (true) {
            val index = codec.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream || ++idle >= 20) return eos
                }
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> state.onFormat(type, codec.outputFormat)
                index >= 0 -> {
                    idle = 0
                    val buffer = codec.getOutputBuffer(index)
                    if (buffer != null) state.write(type, buffer, info)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) eos = true
                    codec.releaseOutputBuffer(index, false)
                    if (eos) return true
                }
            }
        }
    }

    private fun toPcm16(input: ByteArray, sourceBytes: Int, volume: Int): ByteArray {
        val samples = input.size / sourceBytes
        val out = ByteArray(samples * 2)
        val gain = volume.coerceIn(0, 100) / 100.0
        var si = 0
        var oi = 0
        repeat(samples) {
            var sample = when (sourceBytes) {
                1 -> ((input[si].toInt() and 0xFF) - 128) shl 8
                2 -> ((input[si].toInt() and 0xFF) or (input[si + 1].toInt() shl 8)).toShort().toInt()
                3 -> {
                    var v = (input[si].toInt() and 0xFF) or
                        ((input[si + 1].toInt() and 0xFF) shl 8) or
                        ((input[si + 2].toInt() and 0xFF) shl 16)
                    if ((v and 0x0080_0000) != 0) v = v or -0x0100_0000
                    v shr 8
                }
                4 -> {
                    val v = (input[si].toInt() and 0xFF) or
                        ((input[si + 1].toInt() and 0xFF) shl 8) or
                        ((input[si + 2].toInt() and 0xFF) shl 16) or
                        (input[si + 3].toInt() shl 24)
                    v shr 16
                }
                else -> 0
            }
            sample = (sample * gain).roundToInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            out[oi] = (sample and 0xFF).toByte()
            out[oi + 1] = ((sample ushr 8) and 0xFF).toByte()
            si += sourceBytes
            oi += 2
        }
        return out
    }

    private class CodecInputSurface(
        private val codecSurface: Surface,
        private val width: Int,
        private val height: Int,
    ) {
        private val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        private val context: android.opengl.EGLContext
        private val surface: android.opengl.EGLSurface
        private val program: Int
        private val texture: Int
        private val vertices: FloatBuffer

        init {
            val version = IntArray(2)
            check(EGL14.eglInitialize(display, version, 0, version, 1)) { "EGL initialize failed" }
            val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
            val num = IntArray(1)
            val attrs = intArrayOf(
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGLExt.EGL_RECORDABLE_ANDROID, 1,
                EGL14.EGL_NONE,
            )
            check(EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, num, 0) && num[0] > 0) { "No recordable EGL config" }
            val config = configs[0]!!
            context = EGL14.eglCreateContext(
                display,
                config,
                EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE),
                0,
            )
            check(context != EGL14.EGL_NO_CONTEXT) { "EGL context creation failed" }
            surface = EGL14.eglCreateWindowSurface(display, config, codecSurface, intArrayOf(EGL14.EGL_NONE), 0)
            check(surface != EGL14.EGL_NO_SURFACE) { "EGL surface creation failed" }
            check(EGL14.eglMakeCurrent(display, surface, surface, context)) { "EGL makeCurrent failed" }

            program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
            val tex = IntArray(1)
            GLES20.glGenTextures(1, tex, 0)
            texture = tex[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

            val data = floatArrayOf(
                -1f, -1f, 0f, 1f,
                 1f, -1f, 1f, 1f,
                -1f,  1f, 0f, 0f,
                 1f,  1f, 1f, 0f,
            )
            vertices = ByteBuffer.allocateDirect(data.size * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .apply { put(data); position(0) }
        }

        fun draw(bitmap: Bitmap, ptsUs: Long) {
            check(EGL14.eglMakeCurrent(display, surface, surface, context))
            GLES20.glViewport(0, 0, width, height)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(program)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)

            val pos = GLES20.glGetAttribLocation(program, "aPosition")
            val uv = GLES20.glGetAttribLocation(program, "aTexCoord")
            val sampler = GLES20.glGetUniformLocation(program, "uTexture")
            vertices.position(0)
            GLES20.glEnableVertexAttribArray(pos)
            GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 16, vertices)
            vertices.position(2)
            GLES20.glEnableVertexAttribArray(uv)
            GLES20.glVertexAttribPointer(uv, 2, GLES20.GL_FLOAT, false, 16, vertices)
            GLES20.glUniform1i(sampler, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(pos)
            GLES20.glDisableVertexAttribArray(uv)
            check(EGLExt.eglPresentationTimeANDROID(display, surface, ptsUs * 1000L))
            check(EGL14.eglSwapBuffers(display, surface)) { "EGL swap failed" }
        }

        fun release() {
            try { EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT) } catch (_: Throwable) {}
            try { EGL14.eglDestroySurface(display, surface) } catch (_: Throwable) {}
            try { EGL14.eglDestroyContext(display, context) } catch (_: Throwable) {}
            try { EGL14.eglReleaseThread() } catch (_: Throwable) {}
            try { EGL14.eglTerminate(display) } catch (_: Throwable) {}
        }

        private fun createProgram(vs: String, fs: String): Int {
            fun compile(type: Int, src: String): Int {
                val shader = GLES20.glCreateShader(type)
                GLES20.glShaderSource(shader, src)
                GLES20.glCompileShader(shader)
                val ok = IntArray(1)
                GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0)
                check(ok[0] != 0) { GLES20.glGetShaderInfoLog(shader) }
                return shader
            }
            val v = compile(GLES20.GL_VERTEX_SHADER, vs)
            val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, v)
            GLES20.glAttachShader(p, f)
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            check(ok[0] != 0) { GLES20.glGetProgramInfoLog(p) }
            GLES20.glDeleteShader(v)
            GLES20.glDeleteShader(f)
            return p
        }
    }

    private fun evenAtLeast2(value: Int): Int {
        val v = value.coerceAtLeast(2)
        return if (v % 2 == 0) v else v + 1
    }

    private val AAC_SAMPLE_RATES = setOf(8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000, 64000, 88200, 96000)

    private const val VERTEX_SHADER = """
        attribute vec4 aPosition;
        attribute vec2 aTexCoord;
        varying vec2 vTexCoord;
        void main() {
            gl_Position = aPosition;
            vTexCoord = aTexCoord;
        }
    """

    private const val FRAGMENT_SHADER = """
        precision mediump float;
        uniform sampler2D uTexture;
        varying vec2 vTexCoord;
        void main() {
            gl_FragColor = texture2D(uTexture, vTexCoord);
        }
    """
}
