package org.unofficial.binarywaterfall

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import kotlin.concurrent.thread
import kotlin.math.max

class RawAudioPlayer {
    private val lock = Any()
    private var engine: BinaryWaterfallEngine? = null
    private var track: AudioTrack? = null
    private var writer: Thread? = null
    private var running = false
    private var playing = false
    private var baseSourceByte = 0L
    private var pendingSourceByte = 0L
    private var muted = false
    private var outputIsNativeSourceDepth = true

    var onStateChanged: ((Boolean) -> Unit)? = null
    var onEnded: (() -> Unit)? = null

    fun attach(engine: BinaryWaterfallEngine) {
        synchronized(lock) {
            stopLocked(resetPosition = true)
            this.engine = engine
            pendingSourceByte = 0L
        }
    }

    fun detach() {
        synchronized(lock) {
            stopLocked(resetPosition = true)
            engine = null
        }
    }

    fun isPlaying(): Boolean = synchronized(lock) { playing }

    fun currentPositionMs(): Long {
        synchronized(lock) {
            val e = engine ?: return 0L
            val t = track
            if (t == null) return e.msForAudioByte(pendingSourceByte)
            val frames = t.playbackHeadPosition.toLong() and 0xFFFF_FFFFL
            val src = (baseSourceByte + frames * e.sourceFrameBytes.toLong()).coerceAtMost(e.sizeBytes)
            return e.msForAudioByte(src)
        }
    }

    fun play() {
        val stateChanged: Boolean
        synchronized(lock) {
            val e = engine ?: return
            if (!e.isOpen || e.sizeBytes <= 0L) return
            if (track == null) createTrackLocked(pendingSourceByte)
            if (playing) return
            playing = true
            track?.play()
            ensureWriterLocked()
            stateChanged = true
        }
        if (stateChanged) onStateChanged?.invoke(true)
    }

    fun pause() {
        var changed = false
        synchronized(lock) {
            if (playing) {
                playing = false
                try { track?.pause() } catch (_: Throwable) {}
                changed = true
            }
        }
        if (changed) onStateChanged?.invoke(false)
    }

    fun toggle() {
        if (isPlaying()) pause() else play()
    }

    fun seekToMs(ms: Long) {
        var resume = false
        synchronized(lock) {
            val e = engine ?: return
            resume = playing
            val bytePos = e.audioByteForMs(ms)
            stopLocked(resetPosition = false)
            pendingSourceByte = bytePos
            if (resume) {
                createTrackLocked(bytePos)
                playing = true
                track?.play()
                ensureWriterLocked()
            }
        }
        onStateChanged?.invoke(resume)
    }

    fun seekByMs(delta: Long) = seekToMs(currentPositionMs() + delta)

    fun restart() = seekToMs(0L)

    fun setMuted(value: Boolean) {
        synchronized(lock) {
            muted = value
            applyVolumeLocked()
        }
    }

    fun toggleMute(): Boolean {
        synchronized(lock) {
            muted = !muted
            applyVolumeLocked()
            return muted
        }
    }

    fun refreshVolume() {
        synchronized(lock) { applyVolumeLocked() }
    }

    fun release() {
        synchronized(lock) {
            stopLocked(resetPosition = true)
            engine = null
        }
    }

    private fun createTrackLocked(sourceByte: Long) {
        val e = engine ?: return
        baseSourceByte = sourceByte.coerceIn(0L, e.sizeBytes)
        pendingSourceByte = baseSourceByte

        val channelMask = if (e.settings.channels == 1) {
            AudioFormat.CHANNEL_OUT_MONO
        } else {
            AudioFormat.CHANNEL_OUT_STEREO
        }

        val wantedEncoding = when (e.settings.sampleBytes) {
            1 -> AudioFormat.ENCODING_PCM_8BIT
            2 -> AudioFormat.ENCODING_PCM_16BIT
            3 -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) AudioFormat.ENCODING_PCM_24BIT_PACKED else AudioFormat.ENCODING_PCM_16BIT
            4 -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) AudioFormat.ENCODING_PCM_32BIT else AudioFormat.ENCODING_PCM_16BIT
            else -> AudioFormat.ENCODING_PCM_16BIT
        }
        outputIsNativeSourceDepth = (e.settings.sampleBytes <= 2 || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)

        fun build(encoding: Int): AudioTrack {
            val min = AudioTrack.getMinBufferSize(e.settings.sampleRate, channelMask, encoding)
            val bytesPerOutputFrame = e.settings.channels * when (encoding) {
                AudioFormat.ENCODING_PCM_8BIT -> 1
                AudioFormat.ENCODING_PCM_16BIT -> 2
                else -> e.settings.sampleBytes
            }
            val buffer = max(if (min > 0) min else 4096, bytesPerOutputFrame * 4096)
            return AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(encoding)
                        .setSampleRate(e.settings.sampleRate)
                        .setChannelMask(channelMask)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(buffer)
                .build()
        }

        track = try {
            build(wantedEncoding)
        } catch (_: Throwable) {
            outputIsNativeSourceDepth = e.settings.sampleBytes <= 2
            build(if (e.settings.sampleBytes == 1) AudioFormat.ENCODING_PCM_8BIT else AudioFormat.ENCODING_PCM_16BIT)
        }
        applyVolumeLocked()
    }

    private fun ensureWriterLocked() {
        if (running) return
        val e = engine ?: return
        val t = track ?: return
        running = true
        val start = baseSourceByte
        writer = thread(name = "BinaryWaterfallRawAudio", isDaemon = true) {
            var sourcePos = start
            val frameBytes = e.sourceFrameBytes.coerceAtLeast(1)
            val chunkTarget = (64 * 1024 / frameBytes) * frameBytes
            try {
                while (true) {
                    synchronized(lock) {
                        if (!running || track !== t || engine !== e) return@thread
                        if (!playing) {
                            // Leave the stream alive so resume doesn't need to rebuild it.
                        }
                    }
                    if (!isPlaying()) {
                        Thread.sleep(8)
                        continue
                    }

                    if (sourcePos >= e.sizeBytes) {
                        val totalFrames = ((e.sizeBytes - start).coerceAtLeast(0L) / frameBytes)
                        while (true) {
                            synchronized(lock) {
                                if (!running || track !== t || !playing) return@thread
                            }
                            val played = t.playbackHeadPosition.toLong() and 0xFFFF_FFFFL
                            if (played >= totalFrames) break
                            Thread.sleep(5)
                        }
                        synchronized(lock) {
                            if (track === t) {
                                playing = false
                                pendingSourceByte = e.sizeBytes
                                try { t.pause() } catch (_: Throwable) {}
                            }
                        }
                        onStateChanged?.invoke(false)
                        onEnded?.invoke()
                        return@thread
                    }

                    val remaining = (e.sizeBytes - sourcePos).coerceAtMost(chunkTarget.toLong()).toInt()
                    val alignedCount = remaining - (remaining % frameBytes)
                    if (alignedCount <= 0) {
                        sourcePos = e.sizeBytes
                        continue
                    }
                    val raw = e.readAt(sourcePos, alignedCount)
                    if (raw.isEmpty()) {
                        sourcePos = e.sizeBytes
                        continue
                    }
                    val alignedRaw = if (raw.size % frameBytes == 0) raw else raw.copyOf(raw.size - raw.size % frameBytes)
                    if (alignedRaw.isEmpty()) {
                        sourcePos = e.sizeBytes
                        continue
                    }
                    val out = if (outputIsNativeSourceDepth) alignedRaw else pcmTo16(alignedRaw, e.settings.sampleBytes)
                    var offset = 0
                    while (offset < out.size) {
                        synchronized(lock) {
                            if (!running || track !== t || engine !== e) return@thread
                        }
                        if (!isPlaying()) {
                            Thread.sleep(5)
                            continue
                        }
                        val n = t.write(out, offset, out.size - offset, AudioTrack.WRITE_BLOCKING)
                        if (n < 0) throw IllegalStateException("AudioTrack write failed: $n")
                        offset += n
                    }
                    sourcePos += alignedRaw.size
                    synchronized(lock) { pendingSourceByte = sourcePos }
                }
            } catch (_: InterruptedException) {
                // Normal shutdown.
            } catch (_: Throwable) {
                synchronized(lock) {
                    if (track === t) playing = false
                }
                onStateChanged?.invoke(false)
            } finally {
                synchronized(lock) {
                    if (writer === Thread.currentThread()) {
                        running = false
                        writer = null
                    }
                }
            }
        }
    }

    private fun stopLocked(resetPosition: Boolean) {
        if (track != null) {
            val e = engine
            if (!resetPosition && e != null) {
                val frames = track!!.playbackHeadPosition.toLong() and 0xFFFF_FFFFL
                pendingSourceByte = (baseSourceByte + frames * e.sourceFrameBytes.toLong()).coerceAtMost(e.sizeBytes)
            }
        }
        running = false
        playing = false
        writer?.interrupt()
        writer = null
        try { track?.pause() } catch (_: Throwable) {}
        try { track?.flush() } catch (_: Throwable) {}
        try { track?.stop() } catch (_: Throwable) {}
        try { track?.release() } catch (_: Throwable) {}
        track = null
        if (resetPosition) pendingSourceByte = 0L
    }

    private fun applyVolumeLocked() {
        val e = engine ?: return
        val value = if (muted) 0f else (e.settings.volume.coerceIn(0, 100) / 100f)
        try {
            track?.setVolume(value)
        } catch (_: Throwable) {
            @Suppress("DEPRECATION")
            track?.setStereoVolume(value, value)
        }
    }

    private fun pcmTo16(input: ByteArray, sourceBytes: Int): ByteArray {
        if (sourceBytes == 2) return input
        val samples = input.size / sourceBytes
        val out = ByteArray(samples * 2)
        var si = 0
        var oi = 0
        repeat(samples) {
            val sample16 = when (sourceBytes) {
                1 -> ((input[si].toInt() and 0xFF) - 128) shl 8
                3 -> {
                    var v = (input[si].toInt() and 0xFF) or
                        ((input[si + 1].toInt() and 0xFF) shl 8) or
                        ((input[si + 2].toInt() and 0xFF) shl 16)
                    if ((v and 0x0080_0000) != 0) v = v or -0x0100_0000
                    v shr 8
                }
                4 -> {
                    val v = (input[si].toInt() and 0xFF) or
                        ((input[si + 1].toInt() and 0xFF) shl 8) or
                        ((input[si + 2].toInt() and 0xFF) shl 16) or
                        (input[si + 3].toInt() shl 24)
                    v shr 16
                }
                else -> 0
            }.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            out[oi] = (sample16 and 0xFF).toByte()
            out[oi + 1] = ((sample16 shr 8) and 0xFF).toByte()
            si += sourceBytes
            oi += 2
        }
        return out
    }
}
