package org.unofficial.binarywaterfall

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

class WaterfallView(context: Context) : View(context) {
    var engine: BinaryWaterfallEngine? = null
    var positionProvider: (() -> Long)? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = false }

    init {
        setBackgroundColor(Color.rgb(24, 25, 27))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val e = engine
        if (e != null && e.isOpen && width > 0 && height > 0) {
            val bitmap = e.renderBitmap(positionProvider?.invoke() ?: 0L)
            val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            val dw = bitmap.width * scale
            val dh = bitmap.height * scale
            val left = (width - dw) / 2f
            val top = (height - dh) / 2f
            canvas.drawBitmap(bitmap, null, RectF(left, top, left + dw, top + dh), paint)
            bitmap.recycle()
        }
        val fps = e?.settings?.playerFps?.coerceIn(1, 120) ?: 30
        postInvalidateDelayed((1000L / fps).coerceAtLeast(8L))
    }
}
